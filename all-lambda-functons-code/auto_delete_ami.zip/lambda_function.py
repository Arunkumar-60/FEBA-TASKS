import boto3
import json
from datetime import datetime, timedelta, timezone

# Time threshold in minutes
time_threshold_minutes = 5 

# Replace with your instance IDs
instance_ids = ['i-000c62e5118b88d8a']

# Change region_ID if necessary
region_id = "ap-south-1"

ec2 = boto3.client('ec2', region_name=region_id)

def lambda_handler(event, context):
    try:
        # Get all AMIs related to the given instances
        ami_ids = get_amis_for_instances(instance_ids)
        if not ami_ids:
            print('No AMIs found for the given instances.')
        
        # Delete AMIs older than the specified time threshold
        delete_old_amis(ami_ids)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Old AMIs deleted successfully')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error: ' + str(e))
        }

def get_amis_for_instances(instance_ids):
    ami_ids = []
    
    for instance_id in instance_ids:
        print(f'Fetching AMIs for instance ID: {instance_id}')
        response = ec2.describe_images(
            Filters=[
                {
                    'Name': 'tag:InstanceId',
                    'Values': [instance_id]
                }
            ]
        )
        images = response.get('Images', [])
        if not images:
            print(f'No AMIs found for instance ID: {instance_id}')
        for image in images:
            ami_ids.append(image['ImageId'])
    
    print(f'AMIs to process: {ami_ids}')
    return ami_ids

def delete_old_amis(ami_ids):
    time_threshold = datetime.now(timezone.utc) - timedelta(minutes=time_threshold_minutes)
    print(f'Time threshold for deletion: {time_threshold.isoformat()}')
    
    for ami_id in ami_ids:
        try:
            print(f'Processing AMI ID: {ami_id}')
            response = ec2.describe_images(ImageIds=[ami_id])
            images = response.get('Images', [])
            
            if not images:
                print(f'AMI {ami_id} not found.')
                continue
            
            image = images[0]
            creation_time = datetime.strptime(image['CreationDate'], '%Y-%m-%dT%H:%M:%S.%fZ')
            print(f'Creation time of AMI {ami_id}: {creation_time.isoformat()}')
            
            if creation_time < time_threshold:
                # Deregister the AMI
                ec2.deregister_image(ImageId=ami_id)
                print(f'Deregistered AMI {ami_id}')
                
                # Delete associated snapshots (if any)
                for mapping in image.get('BlockDeviceMappings', []):
                    snapshot_id = mapping.get('Ebs', {}).get('SnapshotId')
                    if snapshot_id:
                        ec2.delete_snapshot(SnapshotId=snapshot_id)
                        print(f'Deleted snapshot {snapshot_id} associated with AMI {ami_id}')
            else:
                print(f'AMI {ami_id} is not older than the time threshold.')
        except Exception as e:
            print(f'Failed to process AMI {ami_id}: {str(e)}')


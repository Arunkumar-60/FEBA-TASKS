import boto3
import json
from datetime import datetime

region_id = "ap-south-1"
instances = ['i-000c62e5118b88d8a']
ec2 = boto3.client('ec2', region_name=region_id)

def lambda_handler(event, context):
    try:
        for instance_id in instances:
            instance_name = get_instance_name(instance_id)
            stop_instance(instance_id)
            wait_for_instance(instance_id, 'stopped')
            
            ami_id = create_ami(instance_id, instance_name)
            wait_for_ami(ami_id)
            
            start_instance(instance_id)
        
        return {
            'statusCode': 200,
            'body': json.dumps('AMI created and instance restarted successfully')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps('Error: ' + str(e))
        }

def stop_instance(instance_id):
    ec2.stop_instances(InstanceIds=[instance_id])
    print(f'Stopping instance {instance_id}')

def start_instance(instance_id):
    ec2.start_instances(InstanceIds=[instance_id])
    print(f'Starting instance {instance_id}')

def wait_for_instance(instance_id, state):
    waiter = ec2.get_waiter(f'instance_{state}')
    waiter.wait(InstanceIds=[instance_id])
    print(f'Instance {instance_id} is now {state}')

def get_instance_name(instance_id):
    response = ec2.describe_instances(InstanceIds=[instance_id])
    reservations = response['Reservations']
    if reservations:
        instances = reservations[0]['Instances']
        if instances:
            tags = instances[0].get('Tags', [])
            for tag in tags:
                if tag['Key'] == 'Name':
                    return tag['Value']
    return 'Unknown'

def create_ami(instance_id, instance_name):
    date_str = datetime.now().strftime("%d-%b-%Y").upper()
    ami_name = f'{instance_name}_{date_str}'
    ami_description = "Created by automated AMI event using Lambda function"
    response = ec2.create_image(
        InstanceId=instance_id,
        Name=ami_name,
        Description=ami_description,
        NoReboot=True  # This ensures the instance does not reboot
    )
    ami_id = response["ImageId"]
    print(f'Created AMI {ami_id} for instance {instance_id} with description "{ami_description}"')
    
    # Set the AMI name using tags
    ec2.create_tags(
        Resources=[ami_id],
        Tags=[
            {'Key': 'Name', 'Value': ami_name}
        ]
    )
    
    return ami_id

def wait_for_ami(ami_id):
    waiter = ec2.get_waiter('image_available')
    waiter.wait(ImageIds=[ami_id])
    print(f'AMI {ami_id} is now available')
